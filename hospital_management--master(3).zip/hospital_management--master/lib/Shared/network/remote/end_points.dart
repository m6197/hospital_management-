String LoginEndPoint = "user/login";
String SignupEndPoint = "user/signup";
String UserData = "user";
