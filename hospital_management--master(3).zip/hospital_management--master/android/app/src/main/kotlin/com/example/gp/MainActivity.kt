package com.example.gp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
